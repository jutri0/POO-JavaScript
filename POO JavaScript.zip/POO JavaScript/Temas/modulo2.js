import { greet, saludo } from './modulo1.js';  // Se llama al modulo 1 por su nombre de archivo: "modulo1.js"

const message = saludo("Julian Triana");
const heading = document.createElement("h2");
heading.textContent = message;
document.body.appendChild(heading);

