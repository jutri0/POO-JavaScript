export function saludo(name) {
    return `Este esto fue realizado por, ${name}!`;
  }
  
  